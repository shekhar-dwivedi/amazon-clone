import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyDW1-IhaplJMIAtL6Ig4KWFlxUob9izQCI",
    authDomain: "clone-24847.firebaseapp.com",
    projectId: "clone-24847",
    storageBucket: "clone-24847.appspot.com",
    messagingSenderId: "823228635197",
    appId: "1:823228635197:web:26d3bd0915c40d2921b254",
    measurementId: "G-MX74TNSS2Q"
};

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

export { auth, db };
