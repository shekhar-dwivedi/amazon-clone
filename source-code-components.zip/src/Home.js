import React from "react";
import "./Home.css";
import Product from "./Product";
import homebanner from "./icons/banner.jpg";
import homebanner2 from "./icons/banner2.png";
import homebanner3 from "./icons/banner3.jpg";
import ipad from "./icons/ipad.jpg";
import echo from "./icons/echo.jpg";
import tv from "./icons/tv.jpg";
import buds from "./icons/buds.jpg";
import lamp from "./icons/lamp.jpg";
import watch from "./icons/watch.jpg";
import woman from "./icons/woman.jpg";
import hoodie from "./icons/hoodie.jpg";
import jeans from "./icons/jeans.jpg";
import child from "./icons/child.jpg";
import helmet from "./icons/helment.jpg";
import knife from "./icons/knife.jpg";

function Home() {
  return (
    <div className="home">
      <div className="home__container">
      <img src={homebanner} alt="Great Indian Festival" className="home__image"/>
        <p className="title_text">Electronics in SALE! Upto 80% off!</p>
        <div className="home__row">
          <Product
            id="12321341"
            title="Apple iPad Pro 12.9″ (6th Generation): with M2 chip, 12MP front/12MP and 10MP Back Cameras, Face ID, All-Day Battery Life"
            price={109500}
            rating={4}
            reviews={99548}
            image={ipad}
          />
          <Product
            id="49538094"
            title="Echo Dot (5th Gen) | Smart speaker with Bigger sound, Motion Detection, Temperature Sensor, Alexa and Bluetooth"
            price={5499}
            rating={3}
            reviews={28864}
            image={echo}
          />
          <Product
            id="4903850"
            title="iFFALCON 80.04 cm (32 inches) Bezel-Less S Series HD Ready Smart Android LED TV iFF32S53 (Black)"
            price={7999}
            rating={4}
            reviews={924}
            image={tv}
          />
        </div>

        <div className="home__row">
          <Product
            id="4903850"
            title="realme Buds T300 Truly Wireless in-Ear Earbuds with 30dB ANC, 12.4mm Dynamic Bass Boost Driver with Dolby Atmos Support"
            price={2199}
            rating={3}
            reviews={14922}
            image={buds}
          />
          <Product
            id="23445930"
            title="One94Store Night Lamp, Astronaut Galaxy Projector, for Bedroom, Star Projector Night Light, with Remote Control Timer 360°"
            price={1299}
            rating={2}
            reviews={324}
            image={lamp}
          />
          <Product
            id="3254354345"
            title="Noise Pulse 2 Max 1.85 Display, Bluetooth Calling Smart Watch, 10 Days Battery, 550 NITS Brightness"
            price={5999}
            rating={4}
            reviews={184}
            image={watch}
          />
        </div>
        <img src={homebanner3} alt="Great Indian Festival" className="home__image"/>
        <p className="title_text">Just Launched! Winter Collection</p>
        <div className="home__row">
          <Product
            id="90829332"
            title="GoSriKi Women's Cotton Blend Chikankari Embroidered Straight Kurti"
            price={489}
            rating={4}
            reviews={34421}
            image={woman}
          />
          <Product
            id="4903850"
            title="J B Fashion Men Jeans || Men Jeans Pants || Denim Jeans || Baggy Jeans for Men"
            price={1099}
            rating={3}
            reviews={2684}
            image={jeans}
          />
          <Product
            id="4903850"
            title="Lymio Hoodies || Sweatshirt for Men || Men Hoodie (H-18-19)"
            price={999}
            rating={4}
            reviews={9674}
            image={hoodie}
          />
        </div>
        <img src={homebanner2} alt="Great Indian Festival" className="home__image"/>
        <p className="title_text">Based on your previous orders</p>
        <div className="home__row">
          <Product
            id="90829332"
            title="Humming Bird Kid's 80 Pcs Big Mega Sized Blocks Toys Building and Construction Block Set for Children"
            price={289}
            rating={1}
            reviews={1398}
            image={child}
          />
          <Product
            id="4903850"
            title="Vega Crux ISI Certified Flip-Up Helmet for Men and Women with Clear Visor(Black, Size:M)"
            price={798}
            rating={4}
            reviews={13643}
            image={helmet}
          />
          <Product
            id="4903850"
            title="Dexter-Russell – 2.75 New Haven Style Oyster Knife with Rockland Guard cut resistant gloves"
            price={5748}
            rating={3}
            reviews={1208}
            image={knife}
          />
        </div>
      </div>
    </div>
  );
}

export default Home;